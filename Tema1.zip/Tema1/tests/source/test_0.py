def main():
	a = 2
	b = 3
