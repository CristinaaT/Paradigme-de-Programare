def main():
	x = 2
	y = 3
	z = x + y
	print(z)
