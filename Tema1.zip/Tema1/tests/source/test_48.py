def main():
	y = 3
	for x in [1, 2, 3]:
		s = x + y
		print(s)
		y -= 1
	print(s)
