def main():
	print("Tema 1 - PP")
