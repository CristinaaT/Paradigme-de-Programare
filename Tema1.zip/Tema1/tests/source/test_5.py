def main(a, b, c):
	a = 5
	e = 7
	b = a
	a = 3
	c = 2
	d = c
	c = 7
	e = d
	g = a
	f = b
	return 10
